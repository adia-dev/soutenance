// this file gets auto imported in app:assets/js/components.js
VueView.component('fields-manager', 'system:assets/vue-components/fields-manager.js');
VueView.component('fields-renderer', 'system:assets/vue-components/fields-renderer.js');
VueView.component('icon-picker', 'system:assets/vue-components/icon-picker.js');
